<div id="footer">
    <div class="footNotes">
        <div class="container">
            <div class="row-fluid">
                <div class="span3">
                    <h4 class="brand"><span>V</span>ivanta </h4>
                    <ul class="normal dot">
                        <li><a title="About us" href="http://www.yora.xyz/CodeIgniter/aboutus">About us</a></li>
                        <li><a title="Why  YORA TECH" href="http://www.yora.xyz/CodeIgniter/why- YORA TECH-">Why  YORA TECH</a></li>
                        <li><a title="What we do" href="http://www.yora.xyz/CodeIgniter/whatwedo">What we do</a></li>
                        <li><a title="Portfolio" href="http://www.yora.xyz/CodeIgniter/portfolio" class="dropdown-toggle">Portfolio</a></li>
                        <li><a title="Careers" href="http://www.yora.xyz/CodeIgniter/careers">Careers</a></li>
                        <li><a title="Contact Us" href="http://www.yora.xyz/CodeIgniter/contact">Contact Us</a></li>
                        <li><a title="Services" href="http://www.yora.xyz/CodeIgniter/service">Services</a></li>
                        <li><a title="Sitemap" href="http://www.yora.xyz/CodeIgniter/sitemap">Sitemap</a></li>
                    </ul>
                </div>
                <div class="span3">
                    <h4 class="brand"><a title="Web Portal Development" href="http://www.yora.xyz/CodeIgniter/webportaldevelopment"><span>Web</span> Portal Development</a></h4>
                    <h4 class="brand"><a title="Responsive Web Designing" href="http://www.yora.xyz/CodeIgniter/responsivewebdesign"><span>Responsive Web</span> Designing</a></h4>
                    <h4 class="brand"><a title="Web Hosting and Domain" href="http://www.yora.xyz/CodeIgniter/webhostinganddomain"><span>Web</span> Hosting and Domain</a></h4>
                    <h4 class="brand"><a title="Web Services" href="http://www.yora.xyz/CodeIgniter/webservices"><span>Web</span> Services</a></h4>
                    <h4 class="brand"><a title="Domain Registration" href="http://www.yora.xyz/CodeIgniter/domainregistraion"><span>Domain</span> Registration</a></h4>
                </div>
                <div class="span3">
                    <h4 class="brand"><a title="Digital Marketing Company" href="http://www.yora.xyz/CodeIgniter/digitalmarketing"><span>Digital</span> Marketing</a></h4>
                    <h4 class="brand"><a title="Mobile Apps Development" href="http://www.yora.xyz/CodeIgniter/mobileappsdevelopment"><span>Mobile Apps</span> Development</a></h4>
                    <h4 class="brand"><a title="Content Writing" href="http://www.yora.xyz/CodeIgniter/contentwriting"><span>Content</span> Writing</a></h4>
                    <h4 class="brand"><a title="Corporate Training" href="http://www.yora.xyz/CodeIgniter/corporatetraining"><span>Corporate</span> Training</a></h4>
                </div>
                <div class="span3">
                    <div class="contact_info" itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
                        <div class="phone">
                            <h5>Phone:</h5>
                            <span itemprop="telephone"><a title="Call +91-7795572832" href="tel:+91-93535881835">+91-93535881835</a></span>,<br>
                            <!--<span itemprop="telephone"><a title="Call +91-7899908051" href="tel:+91-7899908051">+91-7899908051</a></span>-->
                        </div>
                        <div class="mail">
                            <h5>Mail:</h5>
                            <span itemprop="email"><a title="Mail to info@ YORA TECH.com" href="mailto:info@ YORA TECH.com">info@ YORATECH.com</a> </span>
                        </div>
                        <div class="adress">
                            <h5>Address:</h5>
                            <span itemprop="streetAddress">YORA TECH </span>
                            <span itemprop="addressLocality">Marathalli</span>
                            <span itemprop="addressRegion">Karnataka, Bengaluru</span>
                            <span itemprop="postalCode">560037</span>
                        </div>
                    </div>
                </div>

                <div class="span12">
                    <div class="span6">
                        <p class="pull-left"> &copy; 2018  YORA TECH: <a title="Web development company" href="http://www.yora.xyz/CodeIgniter/">Web development company</a></p>
                    </div>
                    <div class="span6 pull-right">
                        <ul class="socialIcons">
                            <li><a href="https://www.facebook.com/ YORA TECH" class="glyphicons facebook" data-toggle="tooltip" title="Facebook" target="_blank"><i></i></a></li>
                            <li><a href="https://twitter.com/Think YORA TECH" class="glyphicons twitter" data-toggle="tooltip" title="Twitter" target="_blank"><i></i></a></li>
                            <li><a href="https://plus.google.com/+ YORA TECH/" class="glyphicons google_plus" data-toggle="tooltip" title="Google+" target="_blank" rel="publisher"><i></i></a></li>
                            <li><a href="http://www.linkedin.com/company/ YORA TECH-/" target="_blank" class="glyphicons linked_in" data-toggle="tooltip" title="LinkedIn"><i></i></a></li>
                            <li><a href="http://pinterest.com/think YORA TECH/" target="_blank" class="glyphicons pinterest" data-toggle="tooltip" title="Pinterest"><i></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
