<div class="navbar navbar-static-top">
    <div class="navbar-inner">

        <div class="floating-box"><img src="images/yoralogo.jpg" /></div>
        <div class="floating-box"><img src="images/coollogo_com-864586.png" style="margin-top: 25px;margin-left: -52px;" /></div>

        <div class="container">
            <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>


               <!-- <a class="brand" href="./"><img src="img/yoralogo.png" alt="Web Development Company" title="Web Development Company" width="253" height="101" /></a> -->
                <div class="nav-collapse">

                 <!--<div><a class="brand" style="margin-left:-266px;width:177px" href="./"><img src="img/coollogo_com-864586.png" /><div></div></a></div>-->
<ul class="nav pull-right">
<li class='digital-images active dropdown'> <a href="https://www.yora.xyz/" class="dropdown-toggle">Home</a></li>
<li class=" dropdown">
<a href="http://www.yora.xyz/CodeIgniter/index.php/service" class="dropdown-toggle">service</a>
<ul class="dropdown-menu">
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/digitalmarketing">Digital Marketing</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li>
          <a href="http://www.yora.xyz/service/searchengineoptimization">Search Engine Optimization (SEO)</a>
       </li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/searchenginemarketing">Search Engine Marketing (SEM)</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/ppcmanagementservice">PPC Management service</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/appstoreoptimization">App Store Optimization (ASO)</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/webanalytics">Web Analytics</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/socialmediaoptimization">Social Media Optimization (SMO)</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/onlinereputationmanagement">Online Reputation Management (ORM)</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/affiliatemarketing">Affiliate Marketing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/contentmarketing">Content Marketing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/emailmarketing">Email Marketing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/smsmarketing">SMS Marketing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/socialmediamarketing">Social Media Marketing</a></li>
    </ul>
 </li>
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/web-portal-development">Web Portal Development</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/realestateportal">Real Estate Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/mobilewebsitedevelopment">Mobile Website Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/webapplicationdevelopment">Web Application Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/b2bandb2cecommerceportal">B2B &amp; B2C eCommerce Portal</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/contentmanagementsystem">Content Management System (CMS)</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/mvcarchitecture">MVC Architecture</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/travelportaldevelopment">Travel Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/classifiedsportaldevelopment">Classifieds Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/yellowpagesportaldevelopment">Yellow Pages Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/newsportaldevelopment">News Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/jobportaldevelopment">Job Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/educationportaldevelopment">Education Portal Development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/paymentgatewayintegration">Payment Gateway Integration</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/phonegapappsdevelopment">PhoneGap Apps Development</a></li>
    </ul>
 </li>
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/mobile-apps-development">Mobile Apps Development</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/androidappsdevelopment">Android Apps development</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/iphoneappsdevelopment">iPhone Apps development</a></li>
    </ul>
 </li>
 <li class="digital-images dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/responsivewebdesign">Responsive Web Design</a>
    <ul class="dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/webtemplatedesign">Web Template Design</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/companylogographicsdesign">Company Logo/Graphics Design</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/newsletterdesign">Newsletter Design</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/blogdesign">Blog Design</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/customwebsitedesign">Custom Website Design</a></li>
    </ul>
 </li>
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/content-writing">Content Writing</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/webcontentwriting">Web Content Writing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/seocontentwriting">SEO Content Writing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/articlewriting">Article Writing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/blogposting">Blog Posting</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/forumposting">Forum Posting</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/websitecopywriting">Website Copy Writing</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/pressreleasewriting">Press Release Writing</a></li>
    </ul>
 </li>
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/web-hosting-and-domain">Web Hosting &amp; Domain</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/windowshosting">Windows Hosting</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/vpshosting">VPS Hosting</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/dedicatedservers">Dedicated Servers</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/domainregistraion">Domain Registration</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/namesuggestiontool">Name Suggestion Tool</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/sslcertificates">SSL Certificates</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/whoislookup">Whois Lookup</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/resellerhosting">Reseller Hosting</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/emailhosting">Email Hosting</a></li>
    </ul>
 </li>
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/webservice">Web service</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/restfulservice">RESTful service</a></li>
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/apiserviceprovider">API service Provider</a></li>
    </ul>
 </li>
 <li class="dropdown-submenu">
    <a href="http://www.yora.xyz/CodeIgniter/index.php/service/corporatetraining">Corporate Training</a>
    <ul class="digital-images dropdown-menu unstyled">
       <li><a href="http://www.yora.xyz/CodeIgniter/index.php/service/digitalmarketingcourses">Digital Marketing Courses</a></li>
    </ul>
 </li>
</ul>
</li>
<li>
<li> <a href="http://www.yora.xyz/CodeIgniter/index.php/portfolio" class="dropdown-toggle">Portfolio</a> </li>
<li> <a href="http://www.yora.xyz/developers/">Developers</a> </li>
<li> <a href="http://www.yora.xyz/careers" class="dropdown-toggle">Careers</a> </li>
<li> <a href="http://www.yora.xyz/CodeIgniter/index.php/contactus">Contact</a> </li>
</ul>
</div>
</div>
    </div>
</div>
