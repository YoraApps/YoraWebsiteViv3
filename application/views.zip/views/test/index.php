<!DOCTYPE html>
<html lang = "en">

   <head>
      <meta charset = "utf-8">
      <title>YORA</title>
   </head>

   <body>
      Welcome to YORA - World of imagination
   </body>

</html>
