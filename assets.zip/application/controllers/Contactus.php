<?php
   class Contactus extends CI_Controller {

      public function index() {
        $this->load->view('contactus/index');
      }


   }
?>
