<?php
   class Aboutus extends CI_Controller {

      public function index() {
        $this->load->view('about-us/index');
      }


   }
?>
