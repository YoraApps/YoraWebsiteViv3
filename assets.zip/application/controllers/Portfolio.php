<?php
   class Portfolio extends CI_Controller {

      public function index() {
        $this->load->view('portfolio/index');
      }
   }
?>
