<?php
   class Sitemap extends CI_Controller {

      public function index() {
        $this->load->view('sitemap/index');
      }


   }
?>
