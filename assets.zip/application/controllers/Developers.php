<?php
   class Developers extends CI_Controller {

      public function index() {
        $this->load->view('developers/index');
      }

    }
?>
