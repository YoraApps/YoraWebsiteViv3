<?php
   class Whyyora extends CI_Controller {

      public function index() {
        $this->load->view('why-yora-technologies/index');
      }


   }
?>
